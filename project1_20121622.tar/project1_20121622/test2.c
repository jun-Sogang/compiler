/* comment /* asdf *****/

/* com**
 
   /


  ment*/

/*comerrorb /*
